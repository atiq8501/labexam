<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    if(session('type')==1)
        return redirect()->route('admin.index');
    else if(session('type')==2)
        return redirect()->route('user.index');
    else
        return redirect()->route('login.index');
});


Route::get('/registration','RegistrationController@index')->name('regisatration.index');
Route::post('/registration','RegistrationController@insert');
Route::get('/login','LoginController@index')->name('login.index');
Route::post('/login','LoginController@verify');

Route::get('/logout','LogoutController@index')->name('logout.index');

Route::group(['middleware'=>['session']], function(){
    Route::group(['middleware'=>['verifyadmin']], function(){
        Route::get('/admin','AdminController@index')->name('admin.index');
        Route::get('/admin/profile','AdminController@profile')->name('admin.profile');
        Route::get('/admin/changepassword','AdminController@changePassword')->name('admin.changepassword');
        Route::post('/admin/changepassword','AdminController@updatePassword');
        Route::get('/admin/viewusers','AdminController@viewUsers')->name('admin.viewusers');
    });
    Route::group(['middleware'=>['verifyuser']], function(){
        Route::get('/user','UserController@index')->name('user.index');
        Route::get('/user/profile','UserController@profile')->name('user.profile');
        Route::get('/user/changepassword','UserController@changePassword')->name('user.changepassword');
        Route::post('/user/changepassword','UserController@updatePassword');
    });
});


