<!DOCTYPE html>
<html>
    <title>
       Admin Index
    </title>
   <body>
      <center> <table border="2">
            <tr>
                <td colspan="2">
                    <center>
                        <a href="<?php echo e(route('admin.profile')); ?>">Profile</a>
                    </center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                    <a href="<?php echo e(route('admin.changepassword')); ?>">Change Password</a>
                    </center>
                </td>
            </tr>
        
            <tr>
                <td colspan="2">
                    <center>
                        <a href="<?php echo e(route('admin.viewusers')); ?>">View Users</a>
                    </center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                        <a href="<?php echo e(route('logout.index')); ?>">Logout</a>
                    </center>
                </td>
            </tr>
   </table>
        </center>
    </body>
</html><?php /**PATH C:\Users\ASUS\Desktop\Lab2\Lab\resources\views/admin/index.blade.php ENDPATH**/ ?>