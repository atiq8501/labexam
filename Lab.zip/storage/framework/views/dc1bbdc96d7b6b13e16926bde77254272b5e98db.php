<!DOCTYPE html>
<html>
    <title>
       Profile
    </title>
   <body>
      <center> <table border="2">
            <tr>
                <td colspan="2">
                    <center>
                        Profile
                    </center>
                </td>
            </tr>
        
            <tr>
                <td>ID:</td>
               <td><?php echo e($user->username); ?></td>
            </tr>
            <tr>
                <td>Name:</td>
               <td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <td>Email:</td>
               <td><?php echo e($user->email); ?></td>
            </tr>
            <tr>
                <td>Type:</td>
                <td>
                    <?php if($user->type==1): ?> Admin
                    <?php else: ?> User
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                    <a href="<?php echo e(route('user.index')); ?>">Go Back</a>
                </center>
            </td>
        </tr>
   </table>
        </center>
    </body>
</html><?php /**PATH C:\Users\ASUS\Desktop\Lab2\Lab\resources\views/user/profile.blade.php ENDPATH**/ ?>