<!DOCTYPE html>
<html>
<head>
    <title>Registration as Student</title>
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->
    <script src=""></script>
</head>
<body>

<fieldset>
    <legend>Create Account</legend>
    <center>
        <form method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <table>
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username" value="<?php echo e(old('username')); ?>">*</td>
                    <td><?php echo e($errors->first('username')); ?></td>
                </tr>
                <tr>
                    <td>Name:</td>
                    <td><input type="text" name="name" value="<?php echo e(old('name')); ?>">*</td>
                    <td><?php echo e($errors->first('name')); ?></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type="text" name="email" value="<?php echo e(old('email')); ?>">*</td>
                    <td><?php echo e($errors->first('email')); ?></td>
                </tr>
                
                <tr>
                    <td>Password:</td>
                    <td><input id = "pass" type="password" name="password">*</td>
                    <td><?php echo e($errors->first('password')); ?></td>
                </tr>
                <tr>
                    <td> Confirm Password:</td>
                    <td><input id = "repass" type="password" name="confirmpassword">*</td>
                    <td><?php echo e($errors->first('confirmpassword')); ?></td>
                </tr>

                <tr>
                    <td colspan="2"><center>
                        <select name="type">
                            <option value="2">User</option>
                            <option value="1">Admin</option>
                        </select>
                        </center>
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <center>
                                <input type="submit" name="submit" value="Register">
                         </center>
                    </td>
                </tr>
                <tr>
                        <td colspan="2">
                            <center>
                                Already Have an Account !<br/>
                                <a href="/login">Click Here</a> To Log In
                             </center>
                        </td>
                    </tr>
            </table>
            </form>
    </center>
	
</fieldset>
</body>
</html><?php /**PATH C:\Users\ASUS\Desktop\Lab2\Lab\resources\views/registration/index.blade.php ENDPATH**/ ?>