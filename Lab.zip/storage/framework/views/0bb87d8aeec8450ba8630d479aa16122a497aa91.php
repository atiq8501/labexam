<!DOCTYPE html>
<html>
    <title>
       Change Password
    </title>
   <body>
      <center> <table>
          <form method="post">
              <?php echo e(csrf_field()); ?>

            <tr>
                <td>
                    Current Password:
                </td>
                <td> 
                    <input type="password" name="currentpassword">
                </td>
            </tr>
            <tr>
                <td>
                    New Password:
                </td>
                <td> 
                    <input type="password" name="password">
                </td>
            </tr>
            <tr>
                <td>
                    Confirm Password:
                </td>
                <td> 
                    <input type="password" name="confirmpassword">
                </td>
            </tr>
            <tr>
                <td >
                    <center><input type="submit" name="submit" value="Change Password"></center>
                </td>
                <td >
                    <center><a href="<?php echo e(route('admin.index')); ?>">Home</a></center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <?php echo e(session('msg')); ?>

                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                        <a href="<?php echo e(route('logout.index')); ?>">Logout</a>
                    </center>
                </td>
            </tr>
          </form>
   </table>
        </center>
    </body>
</html><?php /**PATH C:\Users\ASUS\Desktop\Lab2\Lab\resources\views/admin/changepassword.blade.php ENDPATH**/ ?>