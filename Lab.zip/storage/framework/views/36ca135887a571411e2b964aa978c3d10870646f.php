<!DOCTYPE html>
<html>
    <title>
       Users
    </title>
   <body>
      <center> <table border="2">
            <tr>
                <td colspan="4">
                    <center>
                      Users
                    </center>
                </td>
            </tr>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>User Type</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php if($user->type==1): ?> Admin
                        <?php else: ?> User
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            <tr>
                <td colspan="4">
                    <center>
                        <a href="<?php echo e(route('admin.index')); ?>">Go Back</a>
                    </center>
                </td>
            </tr>
   </table>
        </center>
    </body>
</html><?php /**PATH C:\Users\ASUS\Desktop\Lab2\Lab\resources\views/admin/viewusers.blade.php ENDPATH**/ ?>