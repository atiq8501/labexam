<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
class LoginController extends Controller
{
    function index(){
        return view('login.index');
    }
    function verify(Request $req){
        $user = User::where('username', $req->username)
					->where('password', $req->password)
                    ->first();	
        if($user!=null){
            $req->session()->put('username', $req->input('username'));
            $req->session()->put('type', $user->type);
            $req->session()->put('name', $user->name);
			if($user->type==1)
                return redirect()->route('admin.index');
            else if($user->type==2)
                return redirect()->route('user.index');
        }
        else {
            $req->session()->flash('msg', 'invalid username/password');
            return redirect()->route('login.index');
        }
    }
}
