<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use\App\User;

class UserController extends Controller
{
    function index(){
        return view('user.index');
    }
    function profile(){
        $user=User::where('username',session('username'))->first();
        return view('user.profile')->with('user',$user);
    }
    function changePassword(){
        return view('user.changepassword');
    }

    function updatePassword(Request $req){
        $user=User::where('username',session('username'))->first();
        $req->validate([
            'password'=>'required|min:4|max:15',
            'confirmpassword' => 'same:password'
        ]);

        if($user->password!=$req->currentpassword)
        {
            $req->session()->flash('msg', 'invalid current password');
            return redirect()->back();
        }
        else{
            $user=User::where('username',session('username'))->update([
                'password'=>$req->password
            ]);
            if($user) return redirect()->route('user.index');
            else {$req->session()->flash('msg', 'failed');return redirect()->back();}
        }
    }
}

