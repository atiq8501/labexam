<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use\App\User;

class AdminController extends Controller
{
    function index(){
        return view('admin.index');
    }
    function viewUsers(){
        $users=User::all();
        return view('admin.viewusers')->with('users',$users);
    }
    function profile(){
        $user=User::where('username',session('username'))->first();
        return view('admin.profile')->with('user',$user);
    }
    function changePassword(){
        return view('admin.changepassword');
    }

    function updatePassword(Request $req){
        $user=User::where('username',session('username'))->first();
        $req->validate([
            'password'=>'required|min:4|max:15',
            'confirmpassword' => 'same:password'
        ]);

        if($user->password!=$req->currentpassword)
        {
            $req->session()->flash('msg', 'invalid username/password');
            return redirect()->back();
        }
        else{
            $user=User::where('username',session('username'))->update([
                'password'=>$req->password
            ]);
            if($user) return redirect()->route('admin.index');
            else {$req->session()->flash('msg', 'failed');return redirect()->back();}
        }
    }
}
