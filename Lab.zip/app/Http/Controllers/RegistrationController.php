<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

class RegistrationController extends Controller
{
    function index(){
        return view('registration.index');
    }
    function insert(Request $req){
            $req->validate([
                'name'=>'required',
                'email'=>'required',
                'username'=>'required|unique:users,username',
                'password'=>'required|min:4|max:15',
                'confirmpassword' => 'same:password'
            ]);
        
            $user=new User();
            $name=$req->name;
            $email=$req->email;
            $username=$req->username;
            $password=$req->password;
            $type=$req->type;

            $user->name=$name;
            $user->email=$email;
            $user->username=$username;
            $user->password=$password;
            $user->type=$type;

            if($user->save()){
                return redirect()->route('login.index');
            }
    }
}
