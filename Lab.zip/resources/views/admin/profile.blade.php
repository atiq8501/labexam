<!DOCTYPE html>
<html>
    <title>
       Profile
    </title>
   <body>
      <center> <table border="2">
            <tr>
                <td colspan="2">
                    <center>
                        Profile
                    </center>
                </td>
            </tr>
        
            <tr>
                <td>ID:</td>
               <td>{{$user->username}}</td>
            </tr>
            <tr>
                <td>Name:</td>
               <td>{{$user->name}}</td>
            </tr>
            <tr>
                <td>Email:</td>
               <td>{{$user->email}}</td>
            </tr>
            <tr>
                <td>Type:</td>
                <td>
                    @if($user->type==1) Admin
                    @else User
                    @endif
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                    <a href="{{route('admin.index')}}">Go Back</a>
                </center>
            </td>
        </tr>
   </table>
        </center>
    </body>
</html>