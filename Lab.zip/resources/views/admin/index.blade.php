<!DOCTYPE html>
<html>
    <title>
       Admin Index
    </title>
   <body>
      <center> <table border="2">
            <tr>
                <td colspan="2">
                    <center>
                        <a href="{{route('admin.profile')}}">Profile</a>
                    </center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                    <a href="{{route('admin.changepassword')}}">Change Password</a>
                    </center>
                </td>
            </tr>
        
            <tr>
                <td colspan="2">
                    <center>
                        <a href="{{route('admin.viewusers')}}">View Users</a>
                    </center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                        <a href="{{route('logout.index')}}">Logout</a>
                    </center>
                </td>
            </tr>
   </table>
        </center>
    </body>
</html>