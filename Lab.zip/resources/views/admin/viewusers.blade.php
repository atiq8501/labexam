<!DOCTYPE html>
<html>
    <title>
       Users
    </title>
   <body>
      <center> <table border="2">
            <tr>
                <td colspan="4">
                    <center>
                      Users
                    </center>
                </td>
            </tr>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>User Type</th>
            </tr>
            @foreach ($users as $user)
                <tr>
                    <td>{{$user->username}}</td>
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>
                        @if($user->type==1) Admin
                        @else User
                        @endif
                    </td>
                </tr>
            @endforeach
            
            
            <tr>
                <td colspan="4">
                    <center>
                        <a href="{{route('admin.index')}}">Go Back</a>
                    </center>
                </td>
            </tr>
   </table>
        </center>
    </body>
</html>