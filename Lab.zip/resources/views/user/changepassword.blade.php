<!DOCTYPE html>
<html>
    <title>
       Change Password
    </title>
   <body>
      <center> <table>
          <form method="post">
              {{csrf_field()}}
            <tr>
                <td>
                    Current Password:
                </td>
                <td> 
                    <input type="password" name="currentpassword">
                </td>
            </tr>
            <tr>
                <td>
                    New Password:
                </td>
                <td> 
                    <input type="password" name="password">
                </td>
            </tr>
            <tr>
                <td>
                    Confirm Password:
                </td>
                <td> 
                    <input type="password" name="confirmpassword">
                </td>
            </tr>
            <tr>
                <td>
                    <center><input type="submit" name="submit" value="Change Password"></center>
                </td>
                <td >
                    <center><a href="{{route('user.index')}}">Home</a></center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    {{session('msg')}}
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                        <a href="{{route('logout.index')}}">Logout</a>
                    </center>
                </td>
            </tr>
          </form>
   </table>
        </center>
    </body>
</html>