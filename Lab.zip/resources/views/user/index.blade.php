<!DOCTYPE html>
<html>
    <title>
       User Index
    </title>
   <body>
      <center> <table border="2">
            <tr>
                <td colspan="2">
                    <center>
                        <a href="{{route('user.profile')}}">Profile</a>
                    </center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                    <a href="{{route('user.changepassword')}}">Change Password</a>
                    </center>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                        <a href="{{route('logout.index')}}">Logout</a>
                    </center>
                </td>
            </tr>
   </table>
        </center>
    </body>
</html>